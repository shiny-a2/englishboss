# cPanel Passenger entry point
from webhook_app import application
